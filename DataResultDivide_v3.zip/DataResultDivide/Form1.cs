﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using TestData;
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using NPOI.POIFS.FileSystem;
using NPOI.Util;
using NPOI.SS.Util;
using NPOI.SS.UserModel;



namespace DataResultDivide
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }




        string fileName,sheetname;
        private void button1_Click(object sender, EventArgs e)
        {
            
            button2.Enabled = true;
            OpenFileDialog ofd = new OpenFileDialog(); //new一个方法

            //"(*.et;*.xls;*.xlsx)|*.et;*.xls;*.xlsx|all|*.*"---------------如果要多种选择
            ofd.Filter = "(*.xls;*.xlsx)|*.xls;*.xlsx";//删选、设定文件显示类型

            ofd.ShowDialog(); //显示打开文件的窗口
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                fileName = ofd.FileName;

            }
            try
            {
                string strCon = null;
                string extension = System.IO.Path.GetExtension(fileName);
                if(extension == ".xlsx")
            {
                 strCon = "Provider = Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties='Excel 8.0;HDR=NO;IMEX=1';";

            }
            else if(extension == ".xls")
            {
                 strCon = "Provider = Microsoft.Jet.OLEDB.4.0;Data Source=" + fileName + ";Extended Properties='Excel 8.0;HDR=NO;IMEX=1';";
            }
            else
            {
                throw new Exception("文件类型不对，请核对信息");
            }

                //string strCon = "Provider = Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties='Excel 8.0;HDR=NO;IMEX=1';";
                //string strCon = "Provider = Microsoft.Jet.OLEDB.4.0;Data Source=" + fileName + ";Extended Properties='Excel 8.0;HDR=NO;IMEX=1';";


                //using (OleDbConnection conn = new OleDbConnection(strCon))
                //{
                //    textBox1.Text = ofd.FileName;
                //    conn.Open();
                  
                //    DataTable sheetName = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "Table" });
                //    string FirstSheetName = sheetName.Rows[0][2].ToString();

                //   // DataTable sheetName = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "Table" });
                //   // string FirstSheetName = sheetName.Rows[0][2].ToString();
                //    Console.WriteLine(FirstSheetName);
                  
                //    string sql = string.Format("SELECT * FROM [{0}]", FirstSheetName);
                //    OleDbDataAdapter ada = new OleDbDataAdapter(sql, strCon);
                //    DataSet set1 = new DataSet();                  
                //    ada.Fill(set1);
                //    Console.WriteLine(set1.Tables[0].Rows[14][2]);
                //    dataGridView1.DataSource = set1.Tables[0];                  
                //    conn.Close();
                //}

                  using (FileStream fs = File.OpenRead(fileName))   //打开myxls.xls文件
                  {
                      HSSFWorkbook wk = new HSSFWorkbook(fs);   //把xls文件中的数据写入wk中
                      DataTable sheetName = null;
                      for (int i = 0; i < wk.NumberOfSheets; i++)  //NumberOfSheets是myxls.xls中总共的表数
                      {
                          ISheet sheet = wk.GetSheetAt(i);   //读取当前表数据
                          Console.WriteLine(sheet.SheetName);
                          sheetName = new DataTable(sheet.SheetName);
                          IRow firstRow = sheet.GetRow(14);
                          int cellCount = firstRow.LastCellNum;
             
                          Console.WriteLine(cellCount);
                          for (int h = 0; h < cellCount; h++){
                            ICell cell = firstRow.GetCell(h);
                             //if (cell != null)
                            // {
                                // string cellValue = cell.StringCellValue;
                               // if (cellValue != null)
                               //  {
                                    DataColumn column = new DataColumn();
                                    sheetName.Columns.Add(column);
                                // }
                             //}
                         }
                          Console.WriteLine(sheet.LastRowNum);
                          for (int j = 0; j <= sheet.LastRowNum; j++)  //LastRowNum 是当前表的总行数
                          {
                              IRow row = sheet.GetRow(j);  //读取当前行数据
                              //创建DataTable的数据行
                              DataRow dataRow = sheetName.NewRow();
                              if (row != null)
                             {
                                  //sbr.Append("-------------------------------------\r\n"); //读取行与行之间的提示界限
                                 for (int k = 0; k < row.LastCellNum; k++)  //LastCellNum 是当前行的总列数
                                  {
                                      //ICell cell = row.GetCell(k);  //当前表格
                                      dataRow[k] = row.GetCell(k);
                                      //if (cell != null)
                                      //{
                                          //sbr.Append(cell.ToString());   //获取表格中的数据并转换为字符串类型
                                     // }
                                 }
                              }
                              sheetName.Rows.Add(dataRow);

                          }
                      }

                      dataGridView1.DataSource = sheetName;               
                      //释放资源
                      fs.Close();
                      wk.Close();
                  }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
          

                        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd2 = new OpenFileDialog(); //new一个方法

            //"(*.et;*.xls;*.xlsx)|*.et;*.xls;*.xlsx|all|*.*"---------------如果要多种选择
            ofd2.Filter = "(*.xls;*.xlsx)|*.xls;*.xlsx";//删选、设定文件显示类型
            textBox2.Text = ofd2.FileName;
            ofd2.ShowDialog(); //显示打开文件的窗口
            if (ofd2.ShowDialog() == DialogResult.OK)
            {
                fileName = ofd2.FileName;

            }
            try
            {
                //string strCon = "Provider = Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties='Excel 8.0;HDR=NO;IMEX=1';";
                string strCon = "Provider = Microsoft.Jet.OLEDB.4.0;Data Source=" + fileName + ";Extended Properties='Excel 8.0;HDR=NO;IMEX=1';";
                using (OleDbConnection conn = new OleDbConnection(strCon))
                {
                    conn.Open();
                    DataTable sheetName = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "Table" });
                    string FirstSheetName = sheetName.Rows[0][2].ToString();
                    string sql = string.Format("SELECT * FROM [{0}]", FirstSheetName);
                    OleDbDataAdapter ada = new OleDbDataAdapter(sql, strCon);
                    DataSet set2 = new DataSet();
                    ada.Fill(set2);
                    dataGridView2.DataSource = set2.Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button2.Enabled = false;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView2.BackgroundColor = Color.White;
            dataGridView3.BackgroundColor = Color.White;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ExportExcel exp = new ExportExcel();
            exp.ExportToExcel("", dataGridView3, "宋体", 12);
        }

        private void button4_Click(object sender, EventArgs e)
        {

            //ConverDgvDataToTable(dataGridView1);
            //ConverDgvDataToTable(dataGridView2);
            //DataTable dt1 = (DataTable)dataGridView1.DataSource;
            //DataTable dt2 = (DataTable)dataGridView2.DataSource;
            
           DataTable newdt = new DataTable("result");
            //DataTable noDataTable = new DataTable("result");
            //DataTable yesDataTable = new DataTable("result2");
            //创建一个空列


           DataColumn dc = new DataColumn("Reference", typeof(String));
           DataColumn dc1 = new DataColumn("SYM_MIRROR", typeof(String));
           DataColumn dc2 = new DataColumn("Quantity", typeof(String));
           DataColumn dc3 = new DataColumn("Part", typeof(String));
           DataColumn dc4 = new DataColumn("PCB Footp", typeof(String));
           DataColumn dc5 = new DataColumn("Descrpition", typeof(String));
           DataColumn dc6 = new DataColumn("Count", typeof(String));
           DataColumn dc7 = new DataColumn("Note", typeof(String));

           newdt.Columns.Add(dc);
           newdt.Columns.Add(dc1);
           newdt.Columns.Add(dc2);
           newdt.Columns.Add(dc3);
           newdt.Columns.Add(dc4);
           newdt.Columns.Add(dc5);
           newdt.Columns.Add(dc6);
           newdt.Columns.Add(dc7);

            for (int row1 = 14; row1 < dataGridView1.Rows.Count; row1++)
            {
                
                string str1,str2,str3,str4,str5;
                
                //str1获取Refrence
                str1 = Convert.ToString(dataGridView1.Rows[row1].Cells[2].Value);
                //str2获取Quantity
                str2 = Convert.ToString(dataGridView1.Rows[row1].Cells[1].Value);
                //str3获取Part
                str3 = Convert.ToString(dataGridView1.Rows[row1].Cells[3].Value);
                //str4获取PCB Footp
                str4 = Convert.ToString(dataGridView1.Rows[row1].Cells[4].Value);
                //str5获取Descrpition
                str5 = Convert.ToString(dataGridView1.Rows[row1].Cells[5].Value);


                char[] separtaor = { ',' };
                string[] spter = str1.Split(separtaor);

                List<string> nostr1 = new List<String>();
                List<string> nostr2 = new List<String>();
                List<string> nostr3 = new List<string>();
                //StringBuilder sb = new StringBuilder();
                //sb.Append("a").Append(",");
                foreach (var a in spter)
                {
                    for (int i = 6; i < dataGridView2.Rows.Count; i++)
                    {
                        var temp = dataGridView2.Rows[i].Cells[0].Value;
                        if (a.Equals(temp))
                        {
                            //Console.WriteLine(dataGridView2.Rows[i].Cells[8].Value);
                            var temp_value = dataGridView2.Rows[i].Cells[8].Value;
                            if (temp_value.Equals("NO"))
                            {
                                nostr1.Add(a);
                            }
                            else if (temp_value.Equals("YES"))
                            {
                                nostr2.Add(a);
                            }
                            else
                            {
                                nostr3.Add(a);
                            }
                        }
                       

                    }

                }


                //DataTable newdt2 = new DataTable();
                nostr3.Count();
                nostr2.Count();
                nostr1.Count();
                
                int  QuantityCount = nostr1.Count + nostr2.Count + nostr3.Count;
                
                //1.创建空行
                if(nostr1.Count > 0)
                {
                    DataRow dr = newdt.NewRow();
                    dr["Reference"] = string.Join(",", nostr1.ToArray());
                    dr["SYM_MIRROR"] = "NO";
                    dr["Quantity"] = str2;
                    dr["Part"] = str3;
                    dr["PCB Footp"] = str4;
                    dr["Descrpition"] = str5;
                    dr["Count"] = nostr1.Count + nostr3.Count;
                    if (str2 != QuantityCount.ToString())
                    {
                        dr["Note"] = "数目计算错误，可能存在数量出错";
                    }
                    newdt.Rows.Add(dr);
                }


                if(nostr2.Count > 0)
                {
                 DataRow dr2 = newdt.NewRow();
                dr2["Reference"] = string.Join(",", nostr2.ToArray());
                dr2["SYM_MIRROR"] = "yes";
                dr2["Quantity"] = str2;
                dr2["Part"] = str3;
                dr2["PCB Footp"] = str4;
                dr2["Descrpition"] = str5;
                dr2["Count"] = nostr2.Count + nostr3.Count;
                if (str2 != QuantityCount.ToString())
                {
                    dr2["Note"] = "数目计算错误，可能存在数量出错";
                }
                newdt.Rows.Add(dr2);
                 }

                if (nostr3.Count > 0)
                {
                    DataRow dr3 = newdt.NewRow();
                    dr3["Note"] = string.Join(",", nostr3.ToArray(),"找不到该编码");
                    newdt.Rows.Add(dr3);

                }
          }
            //for (var yesData = 0; yesData < yesDataTable.Rows.Count; yesData++)
            //{
            //    DataRow dr1 = noDataTable.NewRow();
            //    string str1 = Convert.ToString(yesDataTable.Rows[yesData][0]);
            //    //str2获取Quantity
            // string   str2 = Convert.ToString(yesDataTable.Rows[yesData][2]);
            //    //str3获取Part
            //string    str3 = Convert.ToString(yesDataTable.Rows[yesData][3]);
            //    //str4获取PCB Footp
            // string   str4 = Convert.ToString(yesDataTable.Rows[yesData][4]);
            //    //str5获取Descrpition
            //  string  str5 = Convert.ToString(yesDataTable.Rows[yesData][5]);
            //    dr1["Reference"] = str1;
            //    dr1["SYM_MIRROR"] = "YES";
            //    dr1["Quantity"] = str2;
            //    dr1["Part"] = str3;
            //    dr1["PCB Footp"] = str4;
            //    dr1["Descrpition"] = str5;
            //    //把新建的行 加到 表中
            //    noDataTable.Rows.Add(dr1);
            //}
            dataGridView3.DataSource = newdt;
            
            
           
        }

        //DataGridView数据存到DataTable中的方法
        //public  DataTable ConverDgvDataToTable(DataGridView dgv)
        //{
        //    DataTable dt = new DataTable();
        //    for (int count = 0; count < dgv.Columns.Count; count++)
        //    {
        //        DataColumn dc = new DataColumn(dgv.Columns[count].Name.ToString());
        //        dt.Columns.Add(dc);
        //    }
        //    for (int count = 0; count < dgv.Rows.Count; count++ )
        //    {
        //        DataRow dr = dt.NewRow();
        //        for (int countsub = 0; countsub < dgv.Columns.Count; countsub++)
        //        {
        //            dr[countsub] = dgv.Rows[count].Cells[countsub].Value.ToString();
        //        }
        //        dt.Rows.Add(dr);
        //    }
        //    return dt;
        //}



        private void Clearbutton5_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView2.DataSource = null;
            dataGridView3.DataSource = null;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dr = MessageBox.Show("是否关闭主菜单？", "提示！", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr == DialogResult.Yes)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
        }
    }


}
