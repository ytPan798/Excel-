﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using NPOI.SS.UserModel;
//using NPOI.HSSF.UserModel;
//using NPOI.XSSF.UserModel;
//using NPOI.SS.Util;
//using NPOI;
//using System.IO;
//using System.Data;

//namespace DataResultDivide
//{
//    class readexcel
//    {
//        /// <summary>
//        /// 将excel文件内容读取到DataTable数据表中
//        /// </summary>
//        /// <param name="fileName">文件完整路径名</param>
//        /// <param name="sheetName">指定读取excel工作簿sheet的名称</param>
    
//        /// <returns>DataTable数据表</returns>
//        public  DataTable ReadExcelToDataTable(string fileName, string sheetName = null, bool isFirstRowColumn = true)
//        {
//            //定义要返回的datatable对象
//            DataTable data = new DataTable();
//            NPOI.SS.UserModel.ISheet sheet = null;
//            //数据开始行
//            int startRow = 15;
//            try
//            {
//                if (!File.Exists(fileName))
//                {
//                    return null;
//                }
//                FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
//                //根据文件流创建excel数据结构
//                NPOI.SS.UserModel.IWorkbook workbook = NPOI.SS.UserModel.WorkbookFactory.Create(fs);
//                if (!string.IsNullOrEmpty(sheetName))
//                {
//                    sheet = workbook.GetSheet(sheetName);
//                    if (sheet == null)
//                    {
//                        sheet = workbook.GetSheetAt(1);
//                    }
//                }
//                else
//                {
//                    sheet = workbook.GetSheetAt(1);
//                }
//                if (sheet != null)
//                {
//                    NPOI.SS.UserModel.IRow firstRow = sheet.GetRow(14);
//                    int cellCount = firstRow.LastCellNum;
//                    if (isFirstRowColumn)
//                    {
//                        for (int i = firstRow.FirstCellNum; i < cellCount; ++i)
//                        {
//                            NPOI.SS.UserModel.ICell cell = firstRow.GetCell(i);
//                            if (cell != null)
//                            {
//                                string cellValue = cell.StringCellValue;
//                                if (cellValue != null)
//                                {
//                                    DataColumn column = new DataColumn(cellValue);
//                                    data.Columns.Add(column);
//                                }
//                            }

//                        }
//                        startRow = sheet.FirstRowNum;
//                        for (int a = 0; a <= sheet.FirstRowNum; ++a)
//                        {
//                            startRow = a;
//                        }

//                    }
//                    else
//                    {
//                        startRow = sheet.FirstRowNum;
//                    }
//                    int rowCount = sheet.LastRowNum;
//                    for (int i = startRow; i <= rowCount; ++i)
//                    {
//                        NPOI.SS.UserModel.IRow row = sheet.GetRow(i);
//                        if (row == null) continue;

//                        DataRow dataRow = data.NewRow();
//                        for (int j = row.FirstCellNum; j < cellCount; ++j)
//                        {
//                            if (row.GetCell(j) != null)
//                            {
//                                dataRow[j] = row.GetCell(j).ToString();
//                            }

//                        }
//                        data.Rows.Add(dataRow);
//                    }
//                }
//                return data;
//            }
//            catch (Exception ex)
//            {
//                throw ex;
//            }
//        }
//    }
//}
