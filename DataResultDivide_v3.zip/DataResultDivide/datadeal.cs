﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;
using NPOI.SS.Util;
using System.IO;

namespace DataResultDivide
{
    class datadeal
    {
         public static DataTable ExcelToDataTable(string fileName, string sheetName, bool isFirstRowColumn = true)

        {

            DataTable data = new DataTable();

            try

            {

                IWorkbook workbook = null;  //新建IWorkbook对象

                var fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read);

                string suffix = fileName.Substring(fileName.LastIndexOf(".") + 1, fileName.Length - fileName.LastIndexOf(".") - 1);

                if (suffix == "xls")    //if (fileName.IndexOf(".xls") > 0) // 2003版本

                {

                    workbook = new HSSFWorkbook(fileStream);  //xlsx数据读入workbook

                }

                else

                {

                    workbook = new XSSFWorkbook(fileStream);  //xls数据读入workbook

                }

                var sheet = (sheetName != null) ? workbook.GetSheet(sheetName) : workbook.GetSheetAt(0);//获取sheet

                if (sheet != null)

                    SheetToDataTable(sheet, isFirstRowColumn, ref data);

                else

                    data = null;

                return data;

            }

            catch (Exception ex)

            {

               Console.WriteLine("ExcelToDataTable Exception: " + ex.Message);

                return null;

            }

        }

 

        /// <summary>

        /// 将Excel中的工作薄转换为DataTable

        /// </summary>

        /// <param name="sheet">Excel中的工作薄</param>

        /// <param name="isFirstRowColumn">第一行是否是DataTable的列名</param>

        /// <param name="data">表</param>

        private static void SheetToDataTable(ISheet sheet, bool isFirstRowColumn, ref DataTable data)

        {

            int rowCount = sheet.LastRowNum;    //最后一列的标号

            IRow firstRow = sheet.GetRow(sheet.FirstRowNum);

            int cellCount = firstRow.LastCellNum; //一行最后一个cell的编号 即总的列数

            int startRow = 0;

            if (isFirstRowColumn)

            {

                for (int i = firstRow.FirstCellNum; i < cellCount; ++i)

                {

                    if (firstRow.GetCell(i) == null) continue;

                    //DataColumn column = new DataColumn(firstRow.GetCell(i).StringCellValue);

                    DataColumn column = new DataColumn(firstRow.GetCell(i).ToString());

                    data.Columns.Add(column);

                }

                startRow = sheet.FirstRowNum + 1;

            }

            else

            {

                startRow = sheet.FirstRowNum;

            }

 

 

            for (int i = startRow; i <= rowCount; ++i)

            {

                IRow row = sheet.GetRow(i);

                if (row == null) continue;      //没有数据的行为null　　　　　　　

 

                DataRow dataRow = data.NewRow();

                for (int j = row.FirstCellNum; j < cellCount; ++j)

                {

                    if (row.GetCell(j) != null) //没有数据的单元格也为null

                        dataRow[j - row.FirstCellNum] = row.GetCell(j).ToString();//一般情况下row.FirstCellNum为0，但有时excel中的数据并不在A列，所以需减去，否则将导致溢出，出现异常。

                }

                data.Rows.Add(dataRow);

            }

        }

    }
}
