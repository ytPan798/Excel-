﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NPOI.SS.Util;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;
using System.IO;
using System.Data;
using System.Windows.Forms;


namespace DataResultDivide
{
  public  class ExcelHelper
    {
      


 
 
 


    }
}
